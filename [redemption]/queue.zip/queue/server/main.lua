-- -
-- ESX Community Project
--
--

MySQL.ready(function ()
  Queue.listen({
    debug = Config.Debug,
    sleepTime = Config.SleepTime,
  })
end)

RegisterServerEvent('queue:addJob')
AddEventHandler('queue:addJob', function (job)
  MySQL.Async.execute(
    'INSERT INTO queue_jobs (until_at, event, payload, delta) VALUES (@until_at, @event, @payload, @delta)',
    { ['@until_at'] = job.until_at, ['@event'] = job.event, ['@payload'] = json.encode(job.payload), ['@delta'] = dateToTimestamp(job.delta) },
    function ()
      if Config.Debug == true then
        print('--- Job ' .. job.event .. ' has been added to the queue')
      end
    end
  )
end)
