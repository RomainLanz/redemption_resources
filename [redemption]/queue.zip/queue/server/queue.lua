-- -
-- ESX Community Project
--
--

Queue = {}

Queue.Options = {}

Queue.defaultOptions = {
  debug = false,
  sleepTime = 5000,
}

-- -
-- Listen the queue to execute job when available.
--
-- @return {void}
--
Queue.listen = function (options)
  Queue.Options = mergeTable(Queue.defaultOptions, options)

  Queue.process()
end

Queue.process = function ()
  if Queue.Options.debug == true then
    print('--- Starting to process the queue...')
  end

  MySQL.Async.fetchAll('SELECT * from queue_jobs WHERE until_at IS NULL OR until_at < NOW()', {}, function (jobs)
    if (#jobs == 0) then
      if Queue.Options.debug == true then
        print('--- No Jobs Found...')
      end

      return
    end

    for i = 1, #jobs, 1 do
      if Queue.Options.debug == true then
        print('--- Processing jobs ' .. i)
      end

      TriggerEvent(jobs[i].event, json.decode(jobs[i].payload))

      if Queue.Options.debug == true then
        print('--- Jobs ' .. i .. ' Processed ')
      end

      if jobs[i].delta ~= nil then
        local nextRun = os.date('%Y-%m-%d %X', os.time() + jobs[i].delta)
        MySQL.Async.execute(
          'INSERT INTO queue_jobs (until_at, event, payload, delta) VALUES (@until_at, @event, @payload, @delta)',
          { ['@until_at'] = nextRun, ['@event'] = jobs[i].event, ['@payload'] = jobs[i].payload, ['@delta'] = jobs[i].delta },
          function ()
            if Queue.Options.debug == true then
              print('--- Jobs ' .. i .. ' Reprogrammed ')
            end
          end
        )
      end

      MySQL.Async.execute('DELETE FROM queue_jobs WHERE id = ' .. jobs[i].id)
    end
  end)

  SetTimeout(Queue.Options.sleepTime, Queue.process)
end
