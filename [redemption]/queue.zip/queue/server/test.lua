MySQL.ready(function ()
  TriggerEvent('queue:addJob', {
    event = 'test:Event',
    payload = { playerName = 'SlyK' },
    delta = { sec = 5 }
  })
end)


RegisterServerEvent('test:Event')
AddEventHandler('test:Event', function (options)
  print (options.playerName)
end)

TriggerEvent('queue:addJob', {
  event = 'esx_bankerjob:calculateBankSavings',
  delta = { hour = 4 },
  needEmptyServer = true,
})
