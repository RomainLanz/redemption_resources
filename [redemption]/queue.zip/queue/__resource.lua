 -- -
-- ESX Community Project
--
--

description 'Queue System for FiveM Server'
version '1.0.0'

dependencies {
  'mysql-async',  -- https://github.com/brouznouf/fivem-mysql-async
}

server_scripts {
  '@mysql-async/lib/MySQL.lua',
  'json.lua',
  'utils.lua',
  'config.lua',
  'server/queue.lua',
  'server/main.lua',
}
