-- -
-- ESX Community Project
--
--

Config = {}


-- -
-- Activate the debugging mode
Config.Debug = false

-- -
-- Number in miliseconds to wait when no job is available.
Config.Sleep = 5000

-- -
-- Runs all jobs only when there's no one on the server.
Config.RunJobsWhenEmptyServer = false
