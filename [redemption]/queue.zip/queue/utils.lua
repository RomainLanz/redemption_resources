-- -
-- Merge two table.
--
--
function mergeTable (firstTable, secondTable)
  for k,v in pairs(secondTable) do firstTable[k] = v end

  return firstTable
end

function dateToTimestamp(date)
  if (date.hour == nil) then
    date.hour = 0
  end

  if (date.min == nil) then
    date.min = 0
  end

  if (date.sec == nil) then
    date.sec = 0
  end

  return date.hour * 60 * 60 + date.min * 60 + date.sec
end
