# ESX Community Project

CREATE TABLE queue_jobs (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  created_at DATETIME NOT NULL default NOW(),
  until_at DATETIME,
  delta INT(11) UNSIGNED,
  event VARCHAR(255) NOT NULL,
  payload LONGTEXT,
  PRIMARY KEY (id)
);
